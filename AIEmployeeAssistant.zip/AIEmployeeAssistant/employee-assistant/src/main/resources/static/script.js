const messageInput = document.getElementById("messageInput");
const chatBox = document.getElementById("chatBox");

function handleKey(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
}

function sendQuickMessage(message) {
    messageInput.value = message;
    sendMessage();
}

async function sendMessage() {

    const message = messageInput.value.trim();

    if (message === "") {
        return;
    }

    // Show user message
    addMessage(message, "user");

    messageInput.value = "";

    // Show loading
    addMessage("Thinking...", "bot");

    try {

        const response = await fetch("/api/chat", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                message: message
            })
        });

        if (!response.ok) {
            throw new Error("Server error");
        }

        const data = await response.json();

        // Remove "Thinking..."
        removeLastBotMessage();

        // Show AI response
        addMessage(data.message, "bot");

        // Show returned data
        if (data.data) {
            addData(data.data);
        }

    } catch (error) {

        removeLastBotMessage();

        addMessage(
            "Sorry, I could not connect to the server.",
            "bot"
        );

        console.error(error);
    }
}


function addMessage(message, type) {

    const div = document.createElement("div");

    div.className = "message";

    if (type === "user") {

        div.innerHTML = `
            <div class="message-icon">👤</div>

            <div class="message-content">
                <strong>You</strong>
                <p>${message}</p>
            </div>
        `;

    } else {

        div.innerHTML = `
            <div class="message-icon">🤖</div>

            <div class="message-content">
                <strong>Employee AI</strong>
                <p>${message}</p>
            </div>
        `;
    }

    chatBox.appendChild(div);

    chatBox.scrollTop = chatBox.scrollHeight;
}


function removeLastBotMessage() {

    const messages =
        chatBox.querySelectorAll(".message");

    if (messages.length > 0) {
        messages[messages.length - 1].remove();
    }
}


function addData(data) {

    if (!Array.isArray(data)) {
        data = [data];
    }

    data.forEach(item => {

        const div = document.createElement("div");

        div.className = "result-card";

        if (item.name && item.email) {

            div.innerHTML = `
                <div class="card-title">
                    👤 ${item.name}
                </div>

                <div class="card-row">
                    📧 ${item.email}
                </div>

                <div class="card-row">
                    🏢 ${item.department}
                </div>

                <div class="card-row">
                    🏖️ Leave Balance:
                    <strong>${item.leaveBalance} days</strong>
                </div>
            `;

        } else if (item.title && item.description) {

            div.innerHTML = `
                <div class="card-title">
                    📋 ${item.title}
                </div>

                <div class="card-row">
                    ${item.description}
                </div>

                <div class="card-footer">
                    <span>
                        Status: ${item.status}
                    </span>

                    <span>
                        Priority: ${item.priority}
                    </span>
                </div>
            `;

        } else if (item.startDate && item.endDate) {

            div.innerHTML = `
                <div class="card-title">
                    🏖️ Leave Request #${item.id}
                </div>

                <div class="card-row">
                    📅 ${item.startDate}
                    → ${item.endDate}
                </div>

                <div class="card-row">
                    Days: ${item.numberOfDays}
                </div>

                <div class="card-row">
                    Reason: ${item.reason}
                </div>

                <div class="card-footer">
                    Status: ${item.status}
                </div>
            `;

        } else if (item.content) {

            div.innerHTML = `
                <div class="card-title">
                    📚 ${item.title}
                </div>

                <div class="card-row">
                    ${item.content}
                </div>

                <div class="card-footer">
                    Category: ${item.category}
                </div>
            `;

        } else {

            div.innerHTML = `
                <div class="card-row">
                    ${formatData(item)}
                </div>
            `;
        }

        chatBox.appendChild(div);

    });

    chatBox.scrollTop = chatBox.scrollHeight;
}


function formatData(item) {

    if (typeof item !== "object") {
        return item;
    }

    return Object.entries(item)
        .map(([key, value]) =>
            `<strong>${key}:</strong> ${value}`
        )
        .join("<br>");
}
async function applyLeave() {

    const startDate =
        document.getElementById("startDate").value;

    const endDate =
        document.getElementById("endDate").value;

    const reason =
        document.getElementById("leaveReason").value.trim();

    if (!startDate || !endDate || !reason) {

        alert("Please fill all leave details.");

        return;
    }

    const message =
        `I want to apply for leave from ${startDate} to ${endDate}`;

    addMessage(message, "user");

    try {

        const response = await fetch("/api/chat", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                message: message,
                reason: reason
            })
        });

        const data = await response.json();

        addMessage(data.message, "bot");

        if (data.data) {
            addData(data.data);
        }

    } catch (error) {

        addMessage(
            "Unable to submit leave request.",
            "bot"
        );

        console.error(error);
    }
}