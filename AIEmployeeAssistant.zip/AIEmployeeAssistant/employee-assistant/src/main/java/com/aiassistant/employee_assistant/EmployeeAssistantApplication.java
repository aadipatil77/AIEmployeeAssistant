package com.aiassistant.employee_assistant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeAssistantApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeAssistantApplication.class, args);
	}

}
