package com.aiassistant.employee_assistant.ai.handler;

import com.aiassistant.employee_assistant.ai.Intent;
import com.aiassistant.employee_assistant.dto.ChatRequest;
import com.aiassistant.employee_assistant.dto.ChatResponse;
import com.aiassistant.employee_assistant.entity.ServiceRequest;
import com.aiassistant.employee_assistant.service.ServiceRequestService;
import org.springframework.stereotype.Component;

@Component
public class CreateRequestHandler implements IntentHandler {

    private final ServiceRequestService serviceRequestService;

    public CreateRequestHandler(ServiceRequestService serviceRequestService) {
        this.serviceRequestService = serviceRequestService;
    }

    @Override
    public Intent getIntent() {
        return Intent.CREATE_SERVICE_REQUEST;
    }

    @Override
    public ChatResponse handle(ChatRequest request) {

        ServiceRequest serviceRequest = new ServiceRequest();

        serviceRequest.setTitle(request.getTitle());
        serviceRequest.setDescription(request.getDescription());
        serviceRequest.setStatus("OPEN");
        serviceRequest.setPriority(request.getPriority());

        ServiceRequest savedRequest =
                serviceRequestService.createRequest(serviceRequest);

        return new ChatResponse(
                "Service request created successfully",
                savedRequest
        );
    }
}