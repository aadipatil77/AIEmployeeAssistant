package com.aiassistant.employee_assistant.ai;

public interface AIService {

    String understand(String message);
}