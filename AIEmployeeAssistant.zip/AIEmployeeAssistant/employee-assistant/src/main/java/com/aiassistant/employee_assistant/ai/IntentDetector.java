package com.aiassistant.employee_assistant.ai;

import org.springframework.stereotype.Component;

@Component
public class IntentDetector {

    public Intent detectIntent(String message) {

        String text = message.toLowerCase().trim();
        // CREATE LEAVE REQUEST
        if ((text.contains("apply")
                || text.contains("request")
                || text.contains("take")
                || text.contains("want"))
                &&
                (text.contains("leave")
                        || text.contains("vacation")
                        || text.contains("time off"))) {

            System.out.println("INTENT = CREATE_LEAVE_REQUEST");

            return Intent.CREATE_LEAVE_REQUEST;
        }
        // GET LEAVE BALANCE
        if (text.contains("leave")
                || text.contains("vacation")
                || text.contains("time off")
                || text.contains("days off")) {

            return Intent.GET_LEAVE_BALANCE;
        }
        // GET KNOWLEDGE ARTICLE
        if (text.contains("policy")
                || text.contains("policies")
                || text.contains("work from home")
                || text.contains("wfh")
                || text.contains("guidelines")) {

            System.out.println("INTENT = GET_KNOWLEDGE_ARTICLE");

            return Intent.GET_KNOWLEDGE_ARTICLE;
        }
        // CREATE SERVICE REQUEST
        if ((text.contains("create")
                || text.contains("raise")
                || text.contains("open")
                || text.contains("submit"))
                &&
                (text.contains("request")
                        || text.contains("ticket")
                        || text.contains("issue"))) {

            return Intent.CREATE_SERVICE_REQUEST;
        }

        // GET EMPLOYEES
        if (text.contains("employee")
                || text.contains("employees")
                || text.contains("staff")
                || text.contains("people")
                || text.contains("team")
                || text.contains("workers")) {

            return Intent.GET_EMPLOYEES;
        }

        // GET SERVICE REQUESTS
        if (text.contains("request")
                || text.contains("requests")
                || text.contains("ticket")
                || text.contains("tickets")
                || text.contains("issue")
                || text.contains("issues")) {

            return Intent.GET_SERVICE_REQUESTS;
        }

        return Intent.UNKNOWN;
    }
}