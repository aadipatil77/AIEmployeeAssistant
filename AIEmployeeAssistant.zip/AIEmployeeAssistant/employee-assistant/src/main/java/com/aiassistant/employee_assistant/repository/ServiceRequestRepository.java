package com.aiassistant.employee_assistant.repository;

import com.aiassistant.employee_assistant.entity.ServiceRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceRequestRepository
        extends JpaRepository<ServiceRequest, Long> {

}