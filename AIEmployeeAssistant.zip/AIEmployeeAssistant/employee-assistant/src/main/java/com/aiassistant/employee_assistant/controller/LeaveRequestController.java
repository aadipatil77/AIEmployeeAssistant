package com.aiassistant.employee_assistant.controller;

import com.aiassistant.employee_assistant.entity.LeaveRequest;
import com.aiassistant.employee_assistant.service.LeaveRequestService;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/leave-requests")
public class LeaveRequestController {

    private final LeaveRequestService leaveRequestService;

    public LeaveRequestController(
            LeaveRequestService leaveRequestService) {

        this.leaveRequestService = leaveRequestService;
    }

    @PostMapping
    public LeaveRequest createLeaveRequest(
            @Valid @RequestBody LeaveRequest leaveRequest) {

        return leaveRequestService
                .createLeaveRequest(leaveRequest);
    }

    @GetMapping
    public List<LeaveRequest> getAllLeaveRequests() {

        return leaveRequestService
                .getAllLeaveRequests();
    }

    @GetMapping("/employee/{employeeId}")
    public List<LeaveRequest> getEmployeeLeaveRequests(
            @PathVariable Long employeeId) {

        return leaveRequestService
                .getEmployeeLeaveRequests(employeeId);
    }

    @GetMapping("/{id}")
    public LeaveRequest getLeaveRequest(
            @PathVariable Long id) {

        return leaveRequestService
                .getLeaveRequestById(id);
    }
    @PutMapping("/{id}/approve")
    public LeaveRequest approveLeaveRequest(
            @PathVariable Long id) {

        return leaveRequestService
                .approveLeaveRequest(id);
    }
    @PutMapping("/{id}/reject")
    public LeaveRequest rejectLeaveRequest(
            @PathVariable Long id) {

        return leaveRequestService
                .rejectLeaveRequest(id);
    }
}