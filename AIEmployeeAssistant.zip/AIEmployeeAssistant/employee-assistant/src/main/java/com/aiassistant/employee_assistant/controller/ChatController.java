package com.aiassistant.employee_assistant.controller;

import com.aiassistant.employee_assistant.ai.Intent;
import com.aiassistant.employee_assistant.ai.IntentDetector;
import com.aiassistant.employee_assistant.ai.AIService;
import com.aiassistant.employee_assistant.ai.handler.IntentHandler;
import com.aiassistant.employee_assistant.dto.ChatRequest;
import com.aiassistant.employee_assistant.dto.ChatResponse;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    private final IntentDetector intentDetector;
    private final List<IntentHandler> handlers;
    private final AIService aiService;

    public ChatController(
            IntentDetector intentDetector,
            List<IntentHandler> handlers,
            AIService aiService) {

        this.intentDetector = intentDetector;
        this.handlers = handlers;
        this.aiService = aiService;
    }

    @PostMapping
    public ChatResponse chat(@RequestBody ChatRequest request) {

        // Try AI first
        String aiResult = aiService.understand(request.getMessage());

        System.out.println("AI Result: " + aiResult);

        // Local intent detection
        Intent intent =
                intentDetector.detectIntent(request.getMessage());

        // Find matching handler
        for (IntentHandler handler : handlers) {

            if (handler.getIntent() == intent) {

                return handler.handle(request);
            }
        }

        // No matching intent
        return new ChatResponse(
                "I could not understand your request",
                null
        );
    }
}