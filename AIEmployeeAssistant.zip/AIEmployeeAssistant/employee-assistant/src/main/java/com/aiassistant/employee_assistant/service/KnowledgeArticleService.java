package com.aiassistant.employee_assistant.service;

import com.aiassistant.employee_assistant.entity.KnowledgeArticle;
import com.aiassistant.employee_assistant.repository.KnowledgeArticleRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class KnowledgeArticleService {

    private final KnowledgeArticleRepository knowledgeArticleRepository;

    public KnowledgeArticleService(
            KnowledgeArticleRepository knowledgeArticleRepository) {

        this.knowledgeArticleRepository = knowledgeArticleRepository;
    }

    public KnowledgeArticle createArticle(KnowledgeArticle article) {

        return knowledgeArticleRepository.save(article);
    }

    public List<KnowledgeArticle> getAllArticles() {

        return knowledgeArticleRepository.findAll();
    }

    public List<KnowledgeArticle> searchArticles(String keyword) {

        return knowledgeArticleRepository
                .findByTitleContainingIgnoreCase(keyword);
    }
    public List<KnowledgeArticle> smartSearch(String message) {

        String[] keywords = message
                .toLowerCase()
                .replaceAll("[^a-zA-Z ]", "")
                .split("\\s+");

        List<KnowledgeArticle> articles =
                knowledgeArticleRepository.findAll();

        return articles.stream()
                .filter(article -> {

                    String title =
                            article.getTitle().toLowerCase();

                    for (String keyword : keywords) {

                        if (keyword.length() > 2
                                && title.contains(keyword)) {

                            return true;
                        }
                    }

                    return false;
                })
                .toList();
    }
}