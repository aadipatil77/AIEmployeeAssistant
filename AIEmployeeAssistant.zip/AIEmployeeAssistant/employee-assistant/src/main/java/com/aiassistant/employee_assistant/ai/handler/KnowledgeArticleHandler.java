package com.aiassistant.employee_assistant.ai.handler;

import com.aiassistant.employee_assistant.ai.Intent;
import com.aiassistant.employee_assistant.dto.ChatRequest;
import com.aiassistant.employee_assistant.dto.ChatResponse;
import com.aiassistant.employee_assistant.entity.KnowledgeArticle;
import com.aiassistant.employee_assistant.service.KnowledgeArticleService;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class KnowledgeArticleHandler implements IntentHandler {

    private final KnowledgeArticleService knowledgeArticleService;

    public KnowledgeArticleHandler(
            KnowledgeArticleService knowledgeArticleService) {

        this.knowledgeArticleService = knowledgeArticleService;
    }

    @Override
    public Intent getIntent() {
        return Intent.GET_KNOWLEDGE_ARTICLE;
    }

    @Override
    public ChatResponse handle(ChatRequest request) {

        String message = request.getMessage().toLowerCase();

        List<KnowledgeArticle> matchingArticles =
                knowledgeArticleService.smartSearch(message);


        if (matchingArticles.isEmpty()) {

            return new ChatResponse(
                    "No relevant knowledge article found.",
                    null
            );
        }

        return new ChatResponse(
                "Relevant knowledge article found",
                matchingArticles
        );
    }
}