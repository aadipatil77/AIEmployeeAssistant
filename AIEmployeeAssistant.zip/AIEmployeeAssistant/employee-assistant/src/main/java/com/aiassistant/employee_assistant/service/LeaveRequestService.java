package com.aiassistant.employee_assistant.service;

import com.aiassistant.employee_assistant.entity.LeaveRequest;
import com.aiassistant.employee_assistant.repository.LeaveRequestRepository;
import org.springframework.stereotype.Service;
import com.aiassistant.employee_assistant.repository.EmployeeRepository;
import java.util.List;
import com.aiassistant.employee_assistant.entity.Employee;
import org.springframework.transaction.annotation.Transactional;


@Service
public class LeaveRequestService {

    private final LeaveRequestRepository leaveRequestRepository;
    private final EmployeeRepository employeeRepository;

    public LeaveRequestService(
            LeaveRequestRepository leaveRequestRepository,
            EmployeeRepository employeeRepository) {

        this.leaveRequestRepository = leaveRequestRepository;
        this.employeeRepository = employeeRepository;
    }

    public LeaveRequest createLeaveRequest(
            LeaveRequest leaveRequest) {

        return leaveRequestRepository.save(leaveRequest);
    }

    public List<LeaveRequest> getAllLeaveRequests() {

        return leaveRequestRepository.findAll();
    }

    public List<LeaveRequest> getEmployeeLeaveRequests(
            Long employeeId) {

        return leaveRequestRepository
                .findByEmployeeId(employeeId);
    }
    public List<LeaveRequest> getActiveEmployeeLeaves(
            Long employeeId) {

        List<LeaveRequest> pendingLeaves =
                leaveRequestRepository
                        .findByEmployeeIdAndStatus(
                                employeeId,
                                "PENDING");

        List<LeaveRequest> approvedLeaves =
                leaveRequestRepository
                        .findByEmployeeIdAndStatus(
                                employeeId,
                                "APPROVED");

        pendingLeaves.addAll(approvedLeaves);

        return pendingLeaves;
    }

    public LeaveRequest getLeaveRequestById(Long id) {

        return leaveRequestRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Leave request not found"));
    }
    public boolean hasOverlappingLeave(
            Long employeeId,
            String newStartDate,
            String newEndDate) {

        List<LeaveRequest> existingLeaves =
                getActiveEmployeeLeaves(employeeId);

        for (LeaveRequest leave : existingLeaves) {

            String existingStart = leave.getStartDate();
            String existingEnd = leave.getEndDate();

            if (newStartDate.compareTo(existingEnd) <= 0
                    && newEndDate.compareTo(existingStart) >= 0) {

                return true;
            }
        }

        return false;
    }
    @Transactional
    public LeaveRequest approveLeaveRequest(Long leaveRequestId) {

        // 1. Find leave request
        LeaveRequest leaveRequest =
                getLeaveRequestById(leaveRequestId);

        // 2. Check status
        if (!"PENDING".equals(leaveRequest.getStatus())) {

            throw new RuntimeException(
                    "Only PENDING leave requests can be approved");
        }

        // 3. Find employee
        Employee employee =
                employeeRepository.findById(
                        leaveRequest.getEmployeeId()
                ).orElseThrow(() ->
                        new RuntimeException("Employee not found"));

        // 4. Check leave balance
        if (leaveRequest.getNumberOfDays()
                > employee.getLeaveBalance()) {

            throw new RuntimeException(
                    "Insufficient leave balance");
        }

        // 5. Deduct leave balance
        employee.setLeaveBalance(
                employee.getLeaveBalance()
                        - leaveRequest.getNumberOfDays()
        );

        // 6. Save employee
        employeeRepository.save(employee);

        // 7. Change status
        leaveRequest.setStatus("APPROVED");

        // 8. Save leave request
        return leaveRequestRepository.save(leaveRequest);
    }
    // REJECT LEAVE REQUEST
    public LeaveRequest rejectLeaveRequest(
            Long leaveRequestId) {

        // 1. Find leave request
        LeaveRequest leaveRequest =
                getLeaveRequestById(leaveRequestId);

        // 2. Only PENDING requests can be rejected
        if (!"PENDING".equals(leaveRequest.getStatus())) {

            throw new RuntimeException(
                    "Only PENDING leave requests can be rejected");
        }

        // 3. Change status
        leaveRequest.setStatus("REJECTED");

        // 4. Save updated request
        return leaveRequestRepository.save(leaveRequest);
    }
}