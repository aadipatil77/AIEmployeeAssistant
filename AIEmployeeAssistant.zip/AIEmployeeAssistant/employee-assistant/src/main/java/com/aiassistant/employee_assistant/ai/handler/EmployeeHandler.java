package com.aiassistant.employee_assistant.ai.handler;

import com.aiassistant.employee_assistant.ai.Intent;
import com.aiassistant.employee_assistant.dto.ChatRequest;
import com.aiassistant.employee_assistant.dto.ChatResponse;
import com.aiassistant.employee_assistant.service.EmployeeService;
import org.springframework.stereotype.Component;

@Component
public class EmployeeHandler implements IntentHandler {

    private final EmployeeService employeeService;

    public EmployeeHandler(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @Override
    public Intent getIntent() {
        return Intent.GET_EMPLOYEES;
    }

    @Override
    public ChatResponse handle(ChatRequest request) {
        return new ChatResponse(
                "Employees found successfully",
                employeeService.getAllEmployees()
        );
    }
}