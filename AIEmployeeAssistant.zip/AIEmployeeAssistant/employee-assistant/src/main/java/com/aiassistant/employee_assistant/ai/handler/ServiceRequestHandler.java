package com.aiassistant.employee_assistant.ai.handler;

import com.aiassistant.employee_assistant.ai.Intent;
import com.aiassistant.employee_assistant.dto.ChatRequest;
import com.aiassistant.employee_assistant.dto.ChatResponse;
import com.aiassistant.employee_assistant.service.ServiceRequestService;
import org.springframework.stereotype.Component;

@Component
public class ServiceRequestHandler implements IntentHandler {

    private final ServiceRequestService serviceRequestService;

    public ServiceRequestHandler(ServiceRequestService serviceRequestService) {
        this.serviceRequestService = serviceRequestService;
    }

    @Override
    public Intent getIntent() {
        return Intent.GET_SERVICE_REQUESTS;
    }

    @Override
    public ChatResponse handle(ChatRequest request) {
        return new ChatResponse(
                "Service requests found successfully",
                serviceRequestService.getAllRequests()
        );
    }
}