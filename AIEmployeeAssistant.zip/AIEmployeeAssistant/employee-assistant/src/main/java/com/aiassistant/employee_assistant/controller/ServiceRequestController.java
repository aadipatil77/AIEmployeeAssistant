package com.aiassistant.employee_assistant.controller;

import com.aiassistant.employee_assistant.entity.ServiceRequest;
import com.aiassistant.employee_assistant.service.ServiceRequestService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/service-requests")
public class ServiceRequestController {

    private final ServiceRequestService serviceRequestService;

    public ServiceRequestController(ServiceRequestService serviceRequestService) {
        this.serviceRequestService = serviceRequestService;
    }

    @PostMapping
    public ServiceRequest createRequest(
            @Valid @RequestBody ServiceRequest request) {

        return serviceRequestService.createRequest(request);
    }

    @GetMapping
    public List<ServiceRequest> getAllRequests() {

        return serviceRequestService.getAllRequests();
    }

    @GetMapping("/{id}")
    public ServiceRequest getRequest(@PathVariable Long id) {

        return serviceRequestService.getRequestById(id);
    }
}