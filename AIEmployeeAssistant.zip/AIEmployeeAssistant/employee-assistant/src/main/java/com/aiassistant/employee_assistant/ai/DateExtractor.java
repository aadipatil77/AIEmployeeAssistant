package com.aiassistant.employee_assistant.ai;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateExtractor {

    public static String[] extractDates(String message) {

        Pattern pattern = Pattern.compile(
                "\\d{4}-\\d{2}-\\d{2}"
        );

        Matcher matcher = pattern.matcher(message);

        String startDate = null;
        String endDate = null;

        if (matcher.find()) {
            startDate = matcher.group();
        }

        if (matcher.find()) {
            endDate = matcher.group();
        }

        return new String[]{
                startDate,
                endDate
        };
    }

    public static void main(String[] args) {

        String message =
                "I want leave from 2026-10-20 to 2026-10-22";

        String[] dates =
                extractDates(message);

        System.out.println("Start Date: " + dates[0]);
        System.out.println("End Date: " + dates[1]);
    }
}