package com.aiassistant.employee_assistant.ai;

public enum Intent {

    GET_EMPLOYEES,

    GET_SERVICE_REQUESTS,

    CREATE_SERVICE_REQUEST,

    GET_LEAVE_BALANCE,

    CREATE_LEAVE_REQUEST,

    GET_KNOWLEDGE_ARTICLE,

    UNKNOWN

}