package com.aiassistant.employee_assistant.ai.handler;

import com.aiassistant.employee_assistant.ai.Intent;
import com.aiassistant.employee_assistant.dto.ChatRequest;
import com.aiassistant.employee_assistant.dto.ChatResponse;
import com.aiassistant.employee_assistant.entity.LeaveRequest;
import com.aiassistant.employee_assistant.service.LeaveRequestService;
import org.springframework.stereotype.Component;
import com.aiassistant.employee_assistant.ai.DateExtractor;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import com.aiassistant.employee_assistant.entity.Employee;
import com.aiassistant.employee_assistant.service.EmployeeService;
@Component
public class CreateLeaveRequestHandler implements IntentHandler {

    private final LeaveRequestService leaveRequestService;
    private final EmployeeService employeeService;

    public CreateLeaveRequestHandler(
            LeaveRequestService leaveRequestService, EmployeeService employeeService) {

        this.leaveRequestService = leaveRequestService;
        this.employeeService = employeeService;
    }

    @Override
    public Intent getIntent() {
        return Intent.CREATE_LEAVE_REQUEST;
    }

    @Override
    public ChatResponse handle(ChatRequest request) {

        // 1. Extract dates from user's message
        String[] dates =
                DateExtractor.extractDates(
                        request.getMessage());

        String startDate = dates[0];
        String endDate = dates[1];

        // 2. Check whether both dates were found
        if (startDate == null || endDate == null) {

            return new ChatResponse(
                    "Please provide leave dates in YYYY-MM-DD format.",
                    null
            );
        }

        // 3. Convert String dates into LocalDate
        LocalDate start =
                LocalDate.parse(startDate);

        LocalDate end =
                LocalDate.parse(endDate);
        if (end.isBefore(start)) {

            return new ChatResponse(
                    "End date cannot be before start date.",
                    null
            );
        }

        // 4. Calculate number of leave days
        int numberOfDays =
                (int) ChronoUnit.DAYS.between(start, end) + 1;
        // Check overlapping leave
        if (leaveRequestService.hasOverlappingLeave(
                1L,
                startDate,
                endDate)) {

            return new ChatResponse(
                    "You already have a pending or approved leave during these dates.",
                    null
            );
        }
        // 5. Get employee
        Employee employee =
                employeeService.getEmployeeById(1L);

        // 6. Check leave balance
        if (numberOfDays > employee.getLeaveBalance()) {

            return new ChatResponse(
                    "Insufficient leave balance. You have only "
                            + employee.getLeaveBalance()
                            + " days remaining.",
                    employee.getLeaveBalance()
            );
        }

        // 7. Create leave request
        LeaveRequest leaveRequest =
                new LeaveRequest();

        leaveRequest.setEmployeeId(1L);

        leaveRequest.setStartDate(startDate);

        leaveRequest.setEndDate(endDate);

        leaveRequest.setNumberOfDays(numberOfDays);

        leaveRequest.setReason(request.getReason());

        leaveRequest.setStatus("PENDING");

        // 8. Save request into database
        LeaveRequest savedRequest =
                leaveRequestService
                        .createLeaveRequest(leaveRequest);

        // 9. Send response
        return new ChatResponse(
                "Leave request created successfully",
                savedRequest
        );
    }
}