package com.aiassistant.employee_assistant.ai;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.Map;

@Service
public class SimpleAIService implements AIService {

    private final RestClient restClient;
    private final String apiKey;
    private final String model;

    public SimpleAIService(
            @Value("${openai.api.key}") String apiKey,
            @Value("${openai.api.url}") String apiUrl,
            @Value("${openai.api.model}") String model) {

        this.apiKey = apiKey;
        this.model = model;

        this.restClient = RestClient.builder()
                .baseUrl(apiUrl)
                .build();
    }

    @Override
    public String understand(String message) {

        try {

            Map<String, Object> requestBody = Map.of(
                    "model", model,
                    "input", message
            );

            Map response = restClient.post()
                    .header("Authorization", "Bearer " + apiKey)
                    .header("Content-Type", "application/json")
                    .body(requestBody)
                    .retrieve()
                    .body(Map.class);

            return response != null
                    ? response.toString()
                    : "AI returned an empty response";

        } catch (Exception e) {

            System.out.println(
                    "OpenAI unavailable. Using local intent detection."
            );

            System.out.println(
                    "Reason: " + e.getMessage()
            );

            return "FALLBACK";
        }
    }
}