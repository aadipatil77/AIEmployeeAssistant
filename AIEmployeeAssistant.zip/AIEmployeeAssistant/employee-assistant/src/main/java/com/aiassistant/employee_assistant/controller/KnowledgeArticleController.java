package com.aiassistant.employee_assistant.controller;

import com.aiassistant.employee_assistant.entity.KnowledgeArticle;
import com.aiassistant.employee_assistant.service.KnowledgeArticleService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/knowledge")
public class KnowledgeArticleController {

    private final KnowledgeArticleService knowledgeArticleService;

    public KnowledgeArticleController(
            KnowledgeArticleService knowledgeArticleService) {

        this.knowledgeArticleService = knowledgeArticleService;
    }

    @PostMapping
    public KnowledgeArticle createArticle(
            @RequestBody KnowledgeArticle article) {

        return knowledgeArticleService.createArticle(article);
    }

    @GetMapping
    public List<KnowledgeArticle> getAllArticles() {

        return knowledgeArticleService.getAllArticles();
    }
}