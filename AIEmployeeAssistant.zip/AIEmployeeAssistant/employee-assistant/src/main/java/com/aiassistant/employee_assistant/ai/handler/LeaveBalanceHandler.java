package com.aiassistant.employee_assistant.ai.handler;

import com.aiassistant.employee_assistant.ai.Intent;
import com.aiassistant.employee_assistant.dto.ChatRequest;
import com.aiassistant.employee_assistant.dto.ChatResponse;
import com.aiassistant.employee_assistant.entity.Employee;
import com.aiassistant.employee_assistant.service.EmployeeService;
import org.springframework.stereotype.Component;

@Component
public class LeaveBalanceHandler implements IntentHandler {

    private final EmployeeService employeeService;

    public LeaveBalanceHandler(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @Override
    public Intent getIntent() {
        return Intent.GET_LEAVE_BALANCE;
    }

    @Override
    public ChatResponse handle(ChatRequest request) {

        // For now, we use employee ID 1
        Employee employee =
                employeeService.getEmployeeById(1L);

        return new ChatResponse(
                "Your remaining leave balance is "
                        + employee.getLeaveBalance()
                        + " days.",
                employee.getLeaveBalance()
        );
    }
}