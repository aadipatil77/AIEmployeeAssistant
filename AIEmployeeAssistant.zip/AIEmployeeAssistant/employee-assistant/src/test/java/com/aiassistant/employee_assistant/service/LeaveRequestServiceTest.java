package com.aiassistant.employee_assistant.service;

import com.aiassistant.employee_assistant.repository.EmployeeRepository;
import com.aiassistant.employee_assistant.repository.LeaveRequestRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import com.aiassistant.employee_assistant.entity.LeaveRequest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.aiassistant.employee_assistant.entity.LeaveRequest;

import java.util.List;

import static org.mockito.Mockito.when;

import com.aiassistant.employee_assistant.entity.Employee;
import com.aiassistant.employee_assistant.entity.LeaveRequest;

import java.util.Optional;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class LeaveRequestServiceTest {

    @Mock
    private LeaveRequestRepository leaveRequestRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    private LeaveRequestService leaveRequestService;

    @BeforeEach
    void setUp() {

        MockitoAnnotations.openMocks(this);

        leaveRequestService =
                new LeaveRequestService(
                        leaveRequestRepository,
                        employeeRepository
                );
    }

    @Test
    void shouldCreateLeaveRequest() {

        LeaveRequest leaveRequest = new LeaveRequest(
                1L,
                "2026-11-10",
                "2026-11-12",
                3,
                "Personal work",
                "PENDING"
        );

        when(leaveRequestRepository.save(leaveRequest))
                .thenReturn(leaveRequest);

        LeaveRequest result =
                leaveRequestService.createLeaveRequest(
                        leaveRequest
                );

        assertEquals("PENDING", result.getStatus());
        assertEquals(3, result.getNumberOfDays());

        verify(leaveRequestRepository)
                .save(leaveRequest);
    }
    @Test
    void shouldDetectOverlappingLeave() {

        LeaveRequest existingLeave =
                new LeaveRequest(
                        1L,
                        "2026-11-10",
                        "2026-11-12",
                        3,
                        "Personal work",
                        "APPROVED"
                );

        when(leaveRequestRepository.findByEmployeeIdAndStatus(
                1L, "PENDING"))
                .thenReturn(new java.util.ArrayList<>());

        when(leaveRequestRepository.findByEmployeeIdAndStatus(
                1L, "APPROVED"))
                .thenReturn(List.of(existingLeave));

        boolean result =
                leaveRequestService.hasOverlappingLeave(
                        1L,
                        "2026-11-11",
                        "2026-11-13"
                );

        assertTrue(result);
    }
    @Test
    void shouldApproveLeaveRequest() {

        LeaveRequest leaveRequest =
                new LeaveRequest(
                        1L,
                        "2026-11-10",
                        "2026-11-12",
                        3,
                        "Personal work",
                        "PENDING"
                );

        Employee employee =
                new Employee(
                        "Aditya",
                        "aditya@gmail.com",
                        "IT",
                        10
                );

        when(leaveRequestRepository.findById(1L))
                .thenReturn(Optional.of(leaveRequest));

        when(employeeRepository.findById(1L))
                .thenReturn(Optional.of(employee));

        when(leaveRequestRepository.save(leaveRequest))
                .thenReturn(leaveRequest);

        LeaveRequest result =
                leaveRequestService.approveLeaveRequest(1L);

        assertEquals("APPROVED", result.getStatus());

        assertEquals(7, employee.getLeaveBalance());

        verify(employeeRepository)
                .save(employee);

        verify(leaveRequestRepository)
                .save(leaveRequest);
    }
    @Test
    void shouldRejectApprovalWhenLeaveBalanceIsInsufficient() {

        LeaveRequest leaveRequest =
                new LeaveRequest(
                        1L,
                        "2026-11-10",
                        "2026-11-14",
                        5,
                        "Personal work",
                        "PENDING"
                );

        Employee employee =
                new Employee(
                        "Aditya",
                        "aditya@gmail.com",
                        "IT",
                        2
                );

        when(leaveRequestRepository.findById(1L))
                .thenReturn(Optional.of(leaveRequest));

        when(employeeRepository.findById(1L))
                .thenReturn(Optional.of(employee));

        RuntimeException exception =
                assertThrows(
                        RuntimeException.class,
                        () -> leaveRequestService
                                .approveLeaveRequest(1L)
                );

        assertEquals(
                "Insufficient leave balance",
                exception.getMessage()
        );

        assertEquals(2, employee.getLeaveBalance());
    }
    @Test
    void shouldRejectApprovalWhenLeaveIsNotPending() {

        LeaveRequest leaveRequest =
                new LeaveRequest(
                        1L,
                        "2026-11-10",
                        "2026-11-12",
                        3,
                        "Personal work",
                        "APPROVED"
                );

        when(leaveRequestRepository.findById(1L))
                .thenReturn(Optional.of(leaveRequest));

        RuntimeException exception =
                assertThrows(
                        RuntimeException.class,
                        () -> leaveRequestService
                                .approveLeaveRequest(1L)
                );

        assertEquals(
                "Only PENDING leave requests can be approved",
                exception.getMessage()
        );
    }
    @Test
    void shouldRejectLeaveRequest() {

        LeaveRequest leaveRequest =
                new LeaveRequest(
                        1L,
                        "2026-11-10",
                        "2026-11-12",
                        3,
                        "Personal work",
                        "PENDING"
                );

        when(leaveRequestRepository.findById(1L))
                .thenReturn(Optional.of(leaveRequest));

        when(leaveRequestRepository.save(leaveRequest))
                .thenReturn(leaveRequest);

        LeaveRequest result =
                leaveRequestService.rejectLeaveRequest(1L);

        assertEquals(
                "REJECTED",
                result.getStatus()
        );

        verify(leaveRequestRepository)
                .save(leaveRequest);
    }
    @Test
    void shouldReturnFalseWhenThereIsNoOverlappingLeave() {

        LeaveRequest existingLeave =
                new LeaveRequest(
                        1L,
                        "2026-11-10",
                        "2026-11-12",
                        3,
                        "Personal work",
                        "APPROVED"
                );

        when(leaveRequestRepository.findByEmployeeIdAndStatus(
                1L, "PENDING"))
                .thenReturn(new java.util.ArrayList<>());

        when(leaveRequestRepository.findByEmployeeIdAndStatus(
                1L, "APPROVED"))
                .thenReturn(List.of(existingLeave));

        boolean result =
                leaveRequestService.hasOverlappingLeave(
                        1L,
                        "2026-11-15",
                        "2026-11-17"
                );

        assertFalse(result);
    }

}