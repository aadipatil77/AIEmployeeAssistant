package com.aiassistant.employee_assistant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeAssistantApplicationTests {

	@Test
	void contextLoads() {
	}

}
